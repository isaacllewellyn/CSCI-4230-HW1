# a simple tcp-server listening on port 1212, preforms a message check and formats a response.
import json
import random
import socket, diffiehell, _thread, sdes

class Object(object):
    pass

def startDHExchange(client):
    print("Startin DH keyexchange")
    prime = diffiehell.getsmallprime()
    msg = "Prime: " + str(prime) + "\n"
    client.clientsocket.send(msg.encode())
    #sent prime over
    #now we get the PubK from out client and send ours to them
    msg = client.clientsocket.recv(512).decode()
    # print(msg)
    client.key = Object()
    client.key.publickey = msg[12:]
    print("Client pubkey set as:", client.key.publickey)
    #generate our Private and Public keys, then  send public back.
    SK = diffiehell.generateSecretKey()
    PK = diffiehell.generatePublicKey( SK, int(prime) )
    #save our sk and pk to use later
    client.key.SK = SK#secret key used for server
    client.key.PK = PK#public key used for server
    msg = "Public Key: " + str(PK) + "\n"
    client.clientsocket.send(msg.encode())
    client.key.KK = pow(int(client.key.publickey), int(client.key.SK), int(prime))
    print("Client shared key:", client.key.KK)
    #save client data to database
    data = json.dumps(client.key.__dict__)
    print(client.address)
    new_file = open(client.name + ".database", mode="w")
    new_file.write(data)
    new_file.close()

#At this point we have established SDES encryption.
def distributeKeys(client):
    msg = client.clientsocket.recv(1024)
    print("Received request: ", msg, "Type:", type(msg))
    #generate SDES keys
    print("Binary: ", bin(client.key.KK))
    client.key.desk1 = sdes.generateK1(client.key.KK)
    client.key.desk2 = sdes.generateK2(client.key.KK)

    msg = sdes.dcryptstring(msg, client.key.desk1, client.key.desk2)

    print("Decrypted request: " + str(msg)[2:] + str(msg)[1])
    if(str(msg)[2] == client.name):
        print("here")
        #client is who they say they are.
        #find the secondary key.
        # try:
        name = str(msg)[4] + '.database'
        database = open(name, 'r')
        print(str(msg)[4] + ".database 29020929" )
        data = database.read()
        print("data", data)
        database.close()
        data = json.loads(data)
        #now we generate as session key for the two parties
        groupKey = random.getrandbits(10)
        # print("Good3")

        #We send this plus, WE encrypt the session with the other's key and send that too!
        #generate second parties keys
        desk1 = sdes.generateK1(data['KK'])
        desk2 = sdes.generateK2(data['KK'])

        print("Encrypting RIGHT HALF WITH KEY: ", data['KK'])
        print("RIGHT HALLF CCCC ", desk1 , desk2, type(desk1), type(desk2))

        #Combine and send to alice
        encm = sdes.encstring(str(groupKey), desk1, desk2)
        message = str(groupKey) + ".." + str(encm)
        print("Good message to bese sent: ", message)
        print("ENC MESSAGGE", encm, "TYPE: ", type(encm))
        print("deccc message to bese sent: ", sdes.dcryptstring(encm, desk1, desk2))

        message = sdes.encstring(message, client.key.desk1, client.key.desk2)
        print("Sending message to client: ", message)
        client.clientsocket.send(message)
        print("Good1")
        #Now we do not need to talk with the client anymore!
        client.clientsocket.close()

        # except:
        #     print("Other party does not exist.")
        #     client.clientsocket.close()
    else:
        print("here2: ", str(msg)[2])

        #client is not who they say they are .... naughty.
        client.clientsocket.close()


def handle_client(client):

    msg = client.clientsocket.recv(1024).decode()
    print("Received msg: ", msg, len(msg[:2]), "DHE: ", len("DHE"))
    if msg[:3] == "DHE":
        client.name = msg[3]


        # f = f.read(100)
        print("Client initiatingg DHE")
        startDHExchange(client)
        print("Client established DHE")
        distributeKeys(client)


s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Bind socket to localhost
hostport = ("localhost", 1212)
s.bind(hostport)
# Launch server socket listener
s.listen(5)
# #
print("Server has been launched. Awaiting clients.")
while True:
    # Accept connections
    clientsocket, address = s.accept()
    client = Object()
    client.clientsocket = clientsocket
    client.address = address
    print("Connection from client: ", address)
    _thread.start_new_thread(handle_client, (client, ))

# # print("data: ", f)
# a = json.loads(f)
# print("enndbui", a)

# print("debug")
# data = ''
# string = "ADB"
# with open(string[2] + '.database', 'r') as f2:
#     data = f2.read()
#     print(data)
# print("F: ", data)