#a simple tcp-socket client connection to a localhost server. Sends a Message to specified server and displays response.
#python 3.0+
import _thread

import ast
#https://stackoverflow.com/questions/45357106/replace-double-backslash-with-single-backslash-in-bytestring
def remove_double_backslashes(b):
    return ast.literal_eval(str(b).replace('\\\\', '\\'))

import socket, diffiehell, message, sdes

import struct
#https://stackoverflow.com/questions/51754731/python-convert-strings-of-bytes-to-byte-array
#spent way too long on this.
def convert_string_to_bytes(string):
    bytes = b''
    for i in string:
        bytes += struct.pack("B", ord(i))
    return bytes
# create an INET, STREAMing socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(("localhost", 1212))
otherport = 1234
myport    = 1233
# s.send(sendstring.encode())
# wait for response from server
# msg = s.recv(1024).decode()
# print ("Received HTML from server:", msg)

#Client establishes use Computational DIffie-Hellman key exchange protocol to SERVER
class Object(object):
    pass

def handle_client(client):
    #if we reach here, we are the first process to run.
    msg = client.clientsocket.recv(1024)
    print("Received msg: ", msg, type(msg), "new:" , str(msg)[2:], type(str(msg)[2:]))
    # print("decrypting message with server shared key")
    print("msg bytes. ")
    msg = msg[2:]
    msg = msg[:len(msg)-1]
    print("Received msg: ", msg, type(msg))
    # msg = convert_string_to_bytes(msg)
    # print("CCCC: ", client.desk1, client.desk2)
    msg = remove_double_backslashes(msg)
    print(sdes.dcryptstring( msg, client.desk1, client.desk2  ))
    if msg[:3] == "DHE":
        client.name = msg[3]


        # f = f.read(100)
        print("Client initiatingg DHE")
        startDHExchange(client)
        print("Client established DHE")
        distributeKeys(client)
# Client loads program. Connects to server.
def startCommunication(a):
    s = a.s
    print("Messaging server...")        #We willl ask the server to establish DHE connection
    sendstring = "DHE" + input("Please enter your id: ")

    s.send(sendstring.encode('utf-8'))  #Sending DHE request
    msg = s.recv(1024).decode()         #Response
    prime  = msg[7:]                    #Parse data out of response
    print ("Received PRIME from server:", prime)
    SK = diffiehell.generateSecretKey()                 #Generate + Store Secret Key and Public Key for client
    PK = diffiehell.generatePublicKey( SK, int(prime) )
    a.prime = prime
    a.SK = SK
    a.PK = PK
    sendstring = "Public Key: " + str(PK)
    s.send(sendstring.encode('utf-8'))                  #Send PK to server
    msg = s.recv(1024).decode()                         #Recieve server PK
    print ("Received Public Key from server:", msg[12:])
    a.SPK = msg[12:]
    a.KK = pow(int(a.SPK), int(a.SK), int(prime))
    print("Client shared key:", a.KK)
    ###Shared key established
    ###Now we will use the shared key to communicate via SDES.

    print("Binary: ", bin(a.KK))
    a.desk1 = sdes.generateK1(a.KK)
    a.desk2 = sdes.generateK2(a.KK)
    print("MY KEY IS ", a.KK)
    # beta = sdes.encstring("mango", a.desk1, a.desk2)
    # sdes.dcryptstring(beta, a.desk1, a.desk2)

    # ##We are now able to communicate with the server at full capacity.
    print( "Now we can request communication to another party"
           "This is done in the form 'A.B'")
    sendstring =  input("Please enter your ID first then '.' then the party you would like to connect to\nIf you want to host enter '.' ")
    # sendstring = "A.B" + message.getBuffer()
    if sendstring == ".":
        print("Starting server, waiting for other party to connect")
        #this means key will be encryped with a.KK
    else:
        sendstring += message.getBuffer() #Add nonce to message.
        sendstring = sdes.encstring(sendstring, a.desk1, a.desk2)
        print("Sending [", sendstring, "]")
        s.send(sendstring)    #Send Request to server
        ##We get our session key
        print("Getting messsage from server")
        msg = s.recv(1024)#Recieve shared P
    # K
    #     msg = msg[2:]
        # msg = msg[0:len(msg/)-1]
        #type string
        # msg = msg.decode()
        # msg = bytes(msg)
        print("Got back: ",  msg, "Type:", type(msg))
        # msg = msg[2:]
        # msg = msg[0:len(m)]
        msg = sdes.dcryptstring(msg, a.desk1, a.desk2)
        print("Decryptedmsg: ", msg)
        #Now we can close connection to the server
        s.close()
        data = msg.split(b'..')
        groupkey = data[0].decode('utf-8')
        dataForOther = data[1]
    try:
        #client is not first
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(("localhost", myport))
        print("Sending: ", dataForOther)
        s.send(dataForOther)
        print(groupkey)
    except Exception as e:
        #client is first
        #doesnt matter
        print(e)
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        # Bind socket to localhost
        hostport = ("localhost", myport)
        s.bind(hostport)
        # Launch server socket listener
        s.listen(5)

        print("Server has been launched. Awaiting clients.")
        while True:
            # Accept connections
            clientsocket, address = s.accept()
            client = Object()
            client.clientsocket = clientsocket
            client.address = address
            client.sharedkey = groupkey
            client.desk1 = a.desk1
            client.desk2 = a.desk2
            print("Connection from client: ", address)
            _thread.start_new_thread(handle_client, (client,))


# Client wants to talk to  B
# Client asks SERVER for BKEY
# Client gets KEY
a = Object()
a.s = s
startCommunication(a)